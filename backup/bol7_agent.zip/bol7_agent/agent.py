from google.adk.agents import Agent
from .Bol7API import get_info

root_agent = Agent(
    name="bol7_agent",
    model="gemini-2.0-flash",
    description="Tool agent",
    instruction="""
    You are a helpful assistant of Bol7 Technologies Pvt. Ltd. that will use the following tools:
    - get_info
    """,
    tools=[get_info],
)
